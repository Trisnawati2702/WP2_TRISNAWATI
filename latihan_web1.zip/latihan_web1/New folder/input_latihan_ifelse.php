<!DOCTYPE html>
<html>
<head>
	<title>Latihan IF ELSE</title>
</head>
<body>
	<center>
	<h2>RUMUS-RUMUS</h2>
	<form action="hasil_ifelse.php" menthod="post">
	<table border="1">
	<tr>
		<td>Nilai 1</td>
		<td><input type="text" name="nilai1"></td>
	</tr>
	<tr>
		<td>Nilai 2</td>
		<td><input type="text" name="nilai2"></td>
	</tr>
	<tr>
		<td align="center">
		    <td colspan="2">
		<input type="radio" name="rumus" value="s">Segitiga<br>
		<input type="radio" name="rumus" value="pp">Persegi Panjang<br>
		</td>
	</tr>
	</table>
	<input type="submit" value="Hitung"><input type="reset" value="Batal">
	</form>
	</center>
</body>
</html>