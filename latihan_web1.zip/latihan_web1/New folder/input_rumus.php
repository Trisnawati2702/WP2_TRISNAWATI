<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scle=1.0">
    <title>Document</title>
</head>
<body>
    <center>
        <h1>Rumus Luas</h1>
        <table border="1" cellspacin="2" align="center">
            <tbody>
                <tr>
                    <td>Nilai 1</td>
                    <td><input type="text" name="Nilai_1"></td>
                </tr>
                <tr>
                    <td>Nilai 2</td>
                    <td><input type="text" name="nilai_2"></td>
                </tr>
                <tr align="center">
                    <td colspan="2"><input type="radio" name="rumus" value="s">Segitiga</td>
                    <input type="radio" name="rumus" value="pp">Persegi Panjang</td>
                </tr>
            </tbody>
        </table>
        <button type="submit" name="submit">Hitung</button>
        <button type="reset" name="reset">Hapus</button>
    </center>
</body>
</html>
